package com.example.mobilevalidation;

public class HospitalList {
	
}
