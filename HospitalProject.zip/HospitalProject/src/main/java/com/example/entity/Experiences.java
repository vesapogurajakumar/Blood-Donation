package com.example.entity;


public class Experiences {
	String message;
}
